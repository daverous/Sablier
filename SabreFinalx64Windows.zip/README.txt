To start the game: click UnityFinallEVELuP.exe


The game will only run on a Microsoft Windows (7 or greater) Computer.

The controllers have to be either XBOX 360 or XBOX One controllers. 

This is because the game uses the Microsoft XInput API for improved control mapping. As a result the game requires directx (windows only) to play.

The Github repository for this project can be found at https://github.com/daverous/Sablier

Please enjoy our game! And what a ride it has been.